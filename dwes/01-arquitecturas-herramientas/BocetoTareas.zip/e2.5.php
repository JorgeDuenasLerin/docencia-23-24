<?php

$pi     = 3.1416;
$r      = 5;
$nombre = "Jorge Dueñas Lerín";

$perimetro = 2 * $pi * $r;
$area = $pi * $r * $r;

?>

<html>
  <head>
    <title>Ejerccio 2.5</title>
    <link rel="stylesheet" type="text/css" href="css/miestilo.css">
  </head>
  <body>
    
    <h1>
      <?= $nombre ?>
    </h1>
    <p>
      El resultado es:<br>
      <span class="item">Área</span>:<span class="resultado"><?= $area ?></span>
      <span class="item">Perímetro</span>:<span class="resultado"><?= $perimetro ?></span>
      
    </p>
    <?php print_r (get_defined_vars()) ?>
  </body>
</html>