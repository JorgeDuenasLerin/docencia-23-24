<?php

// Esto es un comentario
$otra_variable = "Estos es otra variable";
?>
<html>
  <head>
    <title>Mi primera página</title>
  </head>
  <body>
    <h1>
      <?php
        $esto_es_una_variable = "Hola mundo de las variables!";
      
        echo $esto_es_una_variable;
      ?>
    </h1>
    <h2>
      <?= $otra_variable ?>
    </h2>
  </body>
</html>