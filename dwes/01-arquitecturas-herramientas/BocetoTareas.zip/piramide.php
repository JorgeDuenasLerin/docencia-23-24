<?php
function rand_color() {
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}
?>

<html>
  <head>
    <title>Mi primera página</title>
    <link rel="stylesheet" type="text/css" href="css/piramide.css">
  </head>
  <body>
    <?php for($i=0;$i<10;$i++) { ?>
        <div class="bloque" style="background-color:<?=rand_color()?>"></div> 
    <?php } 
        for($i=0;$i<10;$i++) {
          echo "a";
        }
    ?>
    <div class="bloque"></div> 
    <div class="bloque-nl"></div>
    <div class="bloque"></div> 
  </body>
</html>